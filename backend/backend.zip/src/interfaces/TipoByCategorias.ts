export interface TiposByCategoria {
    id_categoria: number;
    id_tipo: number;
    tipo: string;
}