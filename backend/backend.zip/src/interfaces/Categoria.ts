export interface Categoria {
    id_categoria: number,
    categoria: string
}