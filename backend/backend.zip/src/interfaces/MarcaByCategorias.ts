export interface MarcaByCategoria {
    id_categoria: number;
    id_marca: number;
    marca: string;
}