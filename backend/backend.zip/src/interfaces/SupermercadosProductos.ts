export interface SupermercadoProducto {
    id_supermercado: number;
    id_producto: number;
    precio_oferta: string;
    precio_normal: string;
    url_product: string;
    fecha: Date;
    disponibilidad: string;
  }