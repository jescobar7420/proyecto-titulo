export interface Tipo {
    id_tipo: number,
    tipo: string
}