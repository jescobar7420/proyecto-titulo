export interface QuotationDetail {
    id_cotizacion: number;
    id_supermercado: number;
    supermercado: string;
    nombre: string;
    monto_total: number;
    fecha: Date;
}
