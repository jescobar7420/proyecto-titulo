interface Filters {
    supermercados: string;
    precioMin: string;
    precioMax: string;
    categorias: string;
    tipos: string;
    marcas: string;
    order: string;
    offset: number;
}
