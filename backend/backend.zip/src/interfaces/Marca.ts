export interface Marca {
    id_marca: number,
    marca: string
}