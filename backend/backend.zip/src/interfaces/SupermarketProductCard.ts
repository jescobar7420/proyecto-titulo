export interface SupermarketProductCard {
    id_producto: number;
    nombre: string;
    marca: string;
    cantidad: number;
    imagen: string;
    precio_total: number;
    precio_unitario: number;
}
