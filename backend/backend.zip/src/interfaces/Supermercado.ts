export interface Supermercado {
    id_supermercado: number,
    supermercado: string,
    logo: string
}