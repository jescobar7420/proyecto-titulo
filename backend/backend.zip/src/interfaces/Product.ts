export interface Product {
    id_producto?:   number;
    categoria?:     string;
    marca?:         string;
    tipo_producto?: string;
    nombre?:        string;
    imagen?:        string;
    descripcion?:   string;
    ingredientes?:  string;
}
  